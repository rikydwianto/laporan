<?php

$con = mysqli_connect($host, $username, $password, $db_name);
session_start();

?> 