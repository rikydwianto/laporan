<div class="row">
	<div class="content">
		
		<div class="jumbotron text-center">

			<h1 class="page-header devider">403</h1><hr/>
			<h2 class="page-header">Halaman Tidak bisa diakses oleh anda :) </h2>
			<p>Silahkan klik <a href="<?=$url?>">disini</a> untuk ke halaman utama</p>
			<img scr="<?=$url?>assets/403.png" class='img' >

		</div>	
	</div>
</div>