<html>
	<head>
		<title>Ini aplikasi</title>
	</head>
	<style>
	body{
	background-image:url(https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png);
	background-repeat: no-repeat;
	height: 500px; /* You must set a specified height */
  background-position: center; /* Center the image */
  background-repeat: no-repeat; /* Do not repeat the image */

	}
	</style>
	<body>
	<h1 style="color:red;background:blue" >iuni hader 1</h1>
	<h2>iuni hader 1</h2>
	<h3>iuni hader 1</h3>
	</body>
	<footer></footer>
</html>